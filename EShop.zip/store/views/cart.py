from django.shortcuts import render, redirect
from store.models.customer import Customer
from django.contrib.auth.hashers import check_password
from django.contrib import messages
from store.models.product import Product
from store.models.customer import Customer
from django.views import View


class Cart(View):
    def get(self, request):
        cart = request.session.get('cart')
        if not cart:
            request.session.cart = {}
            data = {}
            customers = Customer.get_customer_by_customerid(request.session.get('customer'))
            data['customers'] = customers
            return render(request, 'cart.html', data)

        product_list = list(request.session.get('cart').keys())
        products = Product.get_products_by_id(product_list)
        customers = Customer.get_customer_by_customerid(request.session.get('customer'))
        data = {}
        data['products'] = products
        data['customers'] = customers
        return render(request, 'cart.html', data)
